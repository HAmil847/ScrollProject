// Seleccionar el elemento que contiene el contenido de la página
const content = document.querySelector('.contenido');
//buscar el objeto unity
// 


// Establecer una variable para almacenar la posición actual del scroll
let scrollPos = 0;
let numViews = 100;

//comunicar a unity el numero de vistas
//Enviar a unity
//unityObject.SendMessage("elevator", "NumOfViews", numViews);

// Escuchar el evento "scroll" en la ventana
window.addEventListener('scroll', function() {
  // Obtener la posición actual del scroll
  const currentScrollPos = window.pageYOffset || document.documentElement.scrollTop;

  // Comprobar si el scroll se ha movido hacia arriba o hacia abajo
  if (currentScrollPos > scrollPos) {
    // El scroll ha bajado
   // console.log('Scroll hacia abajo');// Actualizar la posición actual del scroll
  scrollPos += .2;
  } else {
    // El scroll ha subido
   // console.log('Scroll hacia arriba');
   scrollPos -= 1;
  }
  if(scrollPos >=10) scrollPos =0;
  

  console.log(scrollPos);
  //debug
  //console.log(scrollPos);

  
//enviar a unity el valor del scroll
unityInstance.SendMessage("elevator", "Scrolling", scrollPos);


});
